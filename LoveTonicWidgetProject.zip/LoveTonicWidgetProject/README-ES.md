# LoveTonic con widget real de Android

Esta versión mantiene la app HTML dentro de un WebView y añade un `AppWidgetProvider` nativo de Android.
El widget muestra `widgetNote.text` del documento `couples/{codigo}` de Firestore.

## Cómo sacar la APK sin Android Studio
1. Crea un repositorio nuevo en GitHub.
2. Sube TODO el contenido de esta carpeta al repositorio.
3. Ve a **Actions** y ejecuta **Build LoveTonic APK** (también se ejecuta automáticamente al hacer push a `main`).
4. Al terminar, abre el run y descarga el artefacto **LoveTonic-debug-apk**.
5. Extrae `app-debug.apk` e instálalo en los dos móviles.

## Qué hace el widget
- Aparece en el selector de widgets de Android como **Nuestra nota**.
- Al abrir LoveTonic, el HTML pasa al componente nativo el código de pareja y el token de Firebase.
- El widget puede consultar el documento de Firestore y mostrar el último `widgetNote`.
- El widget se actualiza al menos cada 30 minutos por la política normal de App Widgets y también se refresca cuando la app cambia el mensaje en ese móvil.
- Al tocar el widget se abre LoveTonic.

## Importante
El widget usa el token de Firebase del usuario de LoveTonic para leer su documento de pareja. No se abre Firestore públicamente.
