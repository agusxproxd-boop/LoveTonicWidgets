package com.lovetonic.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Context
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("lovetonic_widget", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.addJavascriptInterface(Bridge(this), "LoveTonicBridge")
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    class Bridge(private val context: Context) {
        private val prefs = context.getSharedPreferences("lovetonic_widget", Context.MODE_PRIVATE)

        @JavascriptInterface
        fun setPairCode(code: String?) {
            prefs.edit().putString("pairCode", code ?: "").apply()
            LoveTonicWidgetProvider.updateAll(context)
        }

        @JavascriptInterface
        fun setAuthToken(token: String?) {
            prefs.edit().putString("authToken", token ?: "").apply()
            LoveTonicWidgetProvider.updateAll(context)
        }

        @JavascriptInterface
        fun setWidgetData(text: String?, updatedBy: String?) {
            prefs.edit().putString("note", text ?: "").putString("updatedBy", updatedBy ?: "").apply()
            LoveTonicWidgetProvider.updateAll(context)
        }
    }
}
