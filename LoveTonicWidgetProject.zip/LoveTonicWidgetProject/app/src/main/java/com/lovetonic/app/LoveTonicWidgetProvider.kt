package com.lovetonic.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.Executors

class LoveTonicWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) render(context, manager, id)
        fetchAndRefresh(context)
    }

    companion object {
        private val executor = Executors.newSingleThreadExecutor()

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, LoveTonicWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isNotEmpty()) {
                ids.forEach { render(context, manager, it) }
                fetchAndRefresh(context)
            }
        }

        private fun render(context: Context, manager: AppWidgetManager, id: Int) {
            val p = context.getSharedPreferences("lovetonic_widget", Context.MODE_PRIVATE)
            val note = p.getString("note", "")?.ifBlank { "Abre LoveTonic para conectar 💕" } ?: "Abre LoveTonic para conectar 💕"
            val by = p.getString("updatedBy", "") ?: ""
            val views = RemoteViews(context.packageName, R.layout.widget_note)
            views.setTextViewText(R.id.widgetNote, note)
            views.setTextViewText(R.id.widgetMeta, if (by.isBlank()) "LoveTonic" else "💗 $by")
            val launch = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(context, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widgetNote, pi)
            views.setOnClickPendingIntent(R.id.widgetTitle, pi)
            views.setOnClickPendingIntent(R.id.widgetMeta, pi)
            manager.updateAppWidget(id, views)
        }

        private fun fetchAndRefresh(context: Context) {
            val p = context.getSharedPreferences("lovetonic_widget", Context.MODE_PRIVATE)
            val code = p.getString("pairCode", "") ?: ""
            val token = p.getString("authToken", "") ?: ""
            if (code.isBlank() || token.isBlank()) return
            executor.execute {
                try {
                    val encoded = URLEncoder.encode(code, "UTF-8")
                    val url = URL("https://firestore.googleapis.com/v1/projects/lovetonics/databases/(default)/documents/couples/$encoded")
                    val conn = (url.openConnection() as HttpURLConnection)
                    conn.requestMethod = "GET"
                    conn.setRequestProperty("Authorization", "Bearer $token")
                    conn.connectTimeout = 10000
                    conn.readTimeout = 10000
                    val codeHttp = conn.responseCode
                    if (codeHttp in 200..299) {
                        val body = conn.inputStream.bufferedReader().use { it.readText() }
                        val root = JSONObject(body)
                        val fields = root.optJSONObject("fields") ?: return@execute
                        val state = fields.optJSONObject("state")?.optJSONObject("mapValue")?.optJSONObject("fields") ?: return@execute
                        val wn = state.optJSONObject("widgetNote")?.optJSONObject("mapValue")?.optJSONObject("fields") ?: return@execute
                        val note = wn.optJSONObject("text")?.optString("stringValue", "") ?: ""
                        val by = wn.optJSONObject("updatedByName")?.optString("stringValue", "") ?: ""
                        p.edit().putString("note", note).putString("updatedBy", by).apply()
                        val manager = AppWidgetManager.getInstance(context)
                        val component = ComponentName(context, LoveTonicWidgetProvider::class.java)
                        manager.getAppWidgetIds(component).forEach { render(context, manager, it) }
                    }
                    conn.disconnect()
                } catch (_: Exception) {
                    // El widget conserva el último mensaje conocido si no hay conexión.
                }
            }
        }
    }
}
